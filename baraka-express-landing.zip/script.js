// ====== Konfigurasi kontak (ganti sesuai data asli) ======
const CONFIG = {
  whatsapp: "6281234567890", // format internasional tanpa +
  waText: "Halo Baraka Express, saya ingin bertanya tentang layanan.",
  email: "info@barakaexpress.co.id",
  mapsUrl: "https://maps.google.com/?q=Baraka+Express"
};

document.addEventListener("DOMContentLoaded", () => {
  // Link kontak
  document.querySelectorAll("[data-contact-link]").forEach((el) => {
    const type = el.dataset.contactLink;
    if (type === "whatsapp") {
      el.href = `https://wa.me/${CONFIG.whatsapp}?text=${encodeURIComponent(CONFIG.waText)}`;
      el.target = "_blank"; el.rel = "noopener";
    } else if (type === "email") {
      el.href = `mailto:${CONFIG.email}`;
    } else if (type === "maps") {
      el.href = CONFIG.mapsUrl;
      el.target = "_blank"; el.rel = "noopener";
    }
  });

  // Link materi digital yang belum diisi
  document.querySelectorAll("[data-placeholder-link]").forEach((el) => {
    el.addEventListener("click", (e) => {
      if (el.getAttribute("href") === "#") {
        e.preventDefault();
        alert("Tautan materi ini belum diatur. Ganti href pada index.html.");
      }
    });
  });

  // Navigasi mobile
  const toggle = document.getElementById("navToggle");
  const nav = document.getElementById("mainNav");
  toggle.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    toggle.setAttribute("aria-expanded", open);
  });
  nav.querySelectorAll("a").forEach((a) =>
    a.addEventListener("click", () => {
      nav.classList.remove("open");
      toggle.setAttribute("aria-expanded", "false");
    })
  );

  // Galeri slider
  const track = document.getElementById("galleryTrack");
  const slides = track.children;
  const dotsWrap = document.getElementById("galleryDots");
  const gallery = document.getElementById("gallery");
  let index = 0, timer;

  for (let i = 0; i < slides.length; i++) {
    const b = document.createElement("button");
    b.setAttribute("aria-label", `Gambar ${i + 1}`);
    b.addEventListener("click", () => { go(i); restart(); });
    dotsWrap.appendChild(b);
  }
  const dots = dotsWrap.children;

  function go(i) {
    index = (i + slides.length) % slides.length;
    track.style.transform = `translateX(-${index * 100}%)`;
    [...dots].forEach((d, n) => d.classList.toggle("active", n === index));
  }
  function restart() { clearInterval(timer); timer = setInterval(() => go(index + 1), 4500); }

  document.getElementById("galleryPrev").addEventListener("click", () => { go(index - 1); restart(); });
  document.getElementById("galleryNext").addEventListener("click", () => { go(index + 1); restart(); });
  gallery.addEventListener("mouseenter", () => clearInterval(timer));
  gallery.addEventListener("mouseleave", restart);

  // Swipe
  let startX = null;
  gallery.addEventListener("touchstart", (e) => { startX = e.touches[0].clientX; }, { passive: true });
  gallery.addEventListener("touchend", (e) => {
    if (startX === null) return;
    const dx = e.changedTouches[0].clientX - startX;
    if (Math.abs(dx) > 40) { go(index + (dx < 0 ? 1 : -1)); restart(); }
    startX = null;
  });

  go(0);
  restart();
});
